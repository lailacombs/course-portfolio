# Project Scope

This document contains the scope statement for Laila's Portfolio Website.

The portfolio is a personal website designed to present Laila's previous digital marketing work and introduce future creative projects, including Without Saying, LAISCI, Stories, Lalivia, Charity Projects, and Love, Laila.

The final website currently includes a Home page and an About page, with consistent responsive styling and interactive elements.
