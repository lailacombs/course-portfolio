# Project Retrospective

This document reflects on the portfolio project after development.

## What went well
The site developed a consistent visual identity across both pages while incorporating responsive layout and interactive hover effects.

## What I learned
The project strengthened my understanding of HTML structure, shared CSS styling, navigation between pages, responsive design, and organizing a website project for GitHub Pages.

## What I would improve
Future versions could add individual project pages, stronger imagery, accessibility refinements, and more detailed case studies as the projects in the portfolio develop.
